from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def blog(request):
    return render(request, 'blog.html')

def contact(request):
    return render(request, 'contact.html')

def hotel_room(request):
    return render(request, 'hotel-room.html')

def hotel(request):
    return render(request, 'hotels.html')

def service(request):
    return render(request, 'services.html')

def tour_place(request):
    return render(request, 'tour_place.html')

def tour(request):
    return render(request, 'tours.html')



