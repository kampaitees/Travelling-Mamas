from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name = 'home'),
    path('home', views.home, name = 'home'),
    path('about', views.about, name = 'about'),
    path('blog', views.blog, name = 'blog'),
    path('contact', views.contact, name = 'contact'),
    path('hotel-room', views.hotel_room, name = 'hotel-room'),
    path('hotels', views.hotel, name = 'hotel'),
    path('services', views.service, name = 'services'),
    path('tour-place', views.tour_place, name = 'tour-place'),
    path('tours', views.tour, name = 'tours'),
]
