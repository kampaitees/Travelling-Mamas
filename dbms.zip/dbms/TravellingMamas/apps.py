from django.apps import AppConfig


class TravellingmamasConfig(AppConfig):
    name = 'TravellingMamas'
